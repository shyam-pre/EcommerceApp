import { View, Text } from 'react-native'
import React from 'react'
import { moderateScale } from 'react-native-size-matters'

const OnbordingScreen1 = () => {
  return (
    <View>
      <Text style={{color:'#000', fontSize:moderateScale(20), }}>OnbordingScreen1</Text>
    </View>
  )
}

export default OnbordingScreen1