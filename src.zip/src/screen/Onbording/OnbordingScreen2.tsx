import { View, Text } from 'react-native'
import React from 'react'
import { moderateScale } from 'react-native-size-matters'

const OnbordingScreen2 = () => {
  return (
    <View>
      <Text style={{color:'#000', fontSize:moderateScale(20), }}>OnbordingScreen2</Text>
    </View>
  )
}

export default OnbordingScreen2