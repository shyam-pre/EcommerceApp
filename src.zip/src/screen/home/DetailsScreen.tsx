import { View, Text } from 'react-native'
import React from 'react'

const DetailsScreen = () => {
  return (
    <View>
      <Text style={{fontSize:20, color:'#000'}}>DetailsScreen</Text>
    </View>
  )
}

export default DetailsScreen