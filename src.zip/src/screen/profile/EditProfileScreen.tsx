import React from 'react'
import { View, Text } from 'react-native'

const EditProfile = () => {
  return (
    <View>
      <Text style={{fontSize:20, color:'#000'}}>EditProfile</Text>
    </View>
  )
}

export default EditProfile